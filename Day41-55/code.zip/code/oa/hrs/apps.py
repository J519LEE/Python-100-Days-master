from django.apps import AppConfig


class HrsConfig(AppConfig):
    name = 'hrs'
